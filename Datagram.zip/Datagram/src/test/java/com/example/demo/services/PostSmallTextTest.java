package com.example.demo.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.exceptions.FalseCredentialsException;
import com.example.demo.exceptions.PostContentTooLong;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.PostRepository;
import com.example.demo.repos.UserRepository;

@SpringBootTest
class PostSmallTextTest {
	
	@Autowired
	private PostService postService;
	@Autowired
	private PostRepository postRepo;
	
	@Test
	public void testService() {
		Assertions.assertNotNull(postService);
		Assertions.assertNotNull(postRepo);
	}	

	@Test
	void postSmallTextTest() throws PostContentTooLong {
		User user = new User("datawise", "datawise");
		String content = "Hello world";
		Date date = new Date();
		Post post = new Post(user,date, content );
        //System.out.println(postId+" Result1: " + post.toString());

		Assertions.assertTrue(this.postService.savePost(post));
		Long postId = post.getId();
		Post getPostFromDatabase = this.postRepo.findPostById(postId);
		Assertions.assertTrue(getPostFromDatabase.toString().equals(getPostFromDatabase.toString() ) );
	}
	

}
