package com.example.demo.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.exceptions.FalseCredentialsException;
import com.example.demo.exceptions.UserAlreadyExistsException;
import com.example.demo.model.User;
import com.example.demo.repos.UserRepository;

@SpringBootTest
class logInTest {
	@Autowired
	private UserRepository userRepository;
	
	@Test
	void testRepository() {
		Assertions.assertNotNull(userRepository);
	}
	
	@Test
	void testLogIn() throws FalseCredentialsException {
		User user = this.userRepository.usernameExists("nikos");
		System.out.print(user.getEmail());
		Assertions.assertNotNull(user);
		///Assertions.assertNotNull(userRepository.usernameExists("ilias"));
	}
	
	

}
