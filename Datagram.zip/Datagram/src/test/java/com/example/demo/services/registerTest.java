package com.example.demo.services;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.exceptions.MaxNumberOfRegisteredUsersException;
import com.example.demo.exceptions.UserAlreadyExistsException;
import com.example.demo.model.User;
import com.example.demo.repos.UserRepository;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;


@SpringBootTest
public class registerTest {
	
	@Autowired 
	private UserService userService;
	@Autowired
	private UserRepository userRepo;
	
	@Test
	void testService() {
		Assertions.assertNotNull(userService);
		Assertions.assertNotNull(userRepo);
	}
	
	@Test
	void testRegisterUserAlreadyExists() {
		User newuser = new User("datawise", "datawise");
		this.userRepo.save(newuser);
        assertThrows(UserAlreadyExistsException.class, () -> userService.registerUser(newuser.getUsername(), newuser.getEmail() ));
	}
	
	@Test
	void testUserRegister() throws UserAlreadyExistsException, MaxNumberOfRegisteredUsersException {
		boolean registered = userService.registerUser("makis","makis");
		Assertions.assertTrue(registered ==true);
	}
}
