package com.example.demo.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.exceptions.FalseCredentialsException;
import com.example.demo.model.User;

@SpringBootTest
class AddFollowerTest {

	@Autowired
	private FollowsService followsService;
	@Autowired
	private UserService userService;
	
	@Test
	public void addFollowerStatus() throws FalseCredentialsException {
		User nikos = this.userService.logIn("nikos", "nikos");
		User datawise = this.userService.logIn("datawise", "datawise");

		this.followsService.addFollowerStatus(nikos, datawise);
		Assertions.assertTrue(this.followsService.userFollowsUser(nikos, datawise));
	}
	
	@Test
	public void removeFollowerStatus() throws FalseCredentialsException {
		User nikos = this.userService.logIn("nikos", "nikos");
		User datawise = this.userService.logIn("datawise", "datawise");

		this.followsService.deleteFollowerStatus(nikos, datawise);
		Assertions.assertFalse(this.followsService.userFollowsUser(nikos, datawise));
	}

}
