--SELECT * FROM users;
INSERT INTO users(username,email) VALUES('nikos','nikos');
INSERT INTO users(username,email) VALUES('datawise','datawise');
INSERT INTO users(username,email) VALUES('ilias','ilias');
INSERT INTO users(username,email) VALUES('makis','makis');


INSERT INTO follows(user1email,user2email) VALUES('datawise','nikos');
INSERT INTO follows(user1email,user2email) VALUES('datawise','ilias');
INSERT INTO follows(user1email,user2email) VALUES('datawise','makis');