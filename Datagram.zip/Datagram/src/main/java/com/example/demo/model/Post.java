package com.example.demo.model;

import java.util.ArrayList;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "posts")
public class Post {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@ManyToOne
    @JoinColumn(name = "username", nullable = false)
    private User user;
	@Column
    private String content;

    @Column
    private Date date;
	
	public Post() {
		
	}
	
	public Post(User user, Date date, String content) {
		this.user=user;
		this.date=date;
		this.content=content;
	}//end  constructor
	
	
	
	public String getAuthorsUsername() {
		return this.user.getUsername();
	}//end of method
	
	public String getContent() {
		return this.content;
	}//end of method
	
	public Long getId() {
		return this.id;
	}//end of method
	
	@Override
	public String toString() {
		String post = "\n Post id: "+this.id+
						"\n-----\nDate:"+this.date+
						"\nAuthor:"+this.user.getUsername()+
						"\n"+ this.content+"\n-----\n";
		
		return post;
	}
	
}
