package com.example.demo.exceptions;

public class PostContentTooLong extends Exception {
	public PostContentTooLong(String message) {
        super(message);
    }
}
