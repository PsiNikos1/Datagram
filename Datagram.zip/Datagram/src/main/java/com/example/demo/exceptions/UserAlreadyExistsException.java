package com.example.demo.exceptions;

public class UserAlreadyExistsException extends Exception{

	public UserAlreadyExistsException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
