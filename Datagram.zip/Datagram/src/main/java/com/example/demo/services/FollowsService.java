package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Follows;
import com.example.demo.model.User;
import com.example.demo.repos.FollowsRepository;

import jakarta.transaction.Transactional;

@Service
public class FollowsService {

	@Autowired
	FollowsRepository followsRepository;

	public FollowsService() {
	}//end of constructor
	
	public boolean userFollowsUser(User user1, User user2) {//user1 follows user2.
		return this.followsRepository.userFollowsUser(user1.getEmail(),user2.getEmail());
	}//end of class
	
    @Transactional
	public void addFollowerStatus(User user1, User user2) {
		Follows newFollow = new Follows(user1, user2);
		this.followsRepository.save(newFollow);
		//user2.addFollower(user1);
		user1.addFollowing(user2);
	}//end method
    
	@Transactional
	public void deleteFollowerStatus(User user1, User user2) {
		this.followsRepository.deleteFollowStatus(user1.getEmail(), user2.getEmail());
	}//end method
	
	
}//end of class
