package com.example.demo.model;

import java.util.Date;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "comments")
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "username", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "post_id", nullable = false)
    private Post post;

    @Column
    private Date date;

    @Column
    private String content;

    public Comment() {
    }

    public Comment(User user, Post post, Date date, String content) {
        this.user = user;
        this.post = post;
        this.date = date;
        this.content = content;
    }

    @Override
    public String toString() {
        String comment = "###### "+this.user.getUsername()+": "+this.date+ " " + this.content;
        return comment;
    }//end of method
}//end class
