package com.example.demo.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.FalseCredentialsException;
import com.example.demo.exceptions.UserAlreadyExistsException;
import com.example.demo.model.Comment;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.CommentRepository;
import com.example.demo.repos.PostRepository;
import com.example.demo.repos.UserRepository;


@RestController
@RequestMapping("/users")
public class UserController {

	@Autowired
    private UserRepository userRepository;

	@GetMapping
    @RequestMapping("/getAllUsers")
    public List<User> findAll() {
        return userRepository.getAllUsers();
    }//end of method
    
    
    
    
    @GetMapping
    @RequestMapping("/usernameExists/{username}")
    public User usernameExists(@PathVariable String username) {//Only one user can be found
        User user = userRepository.usernameExists(username);
    	if(user == null) {
        	return null;
        }
        return user;    
    }//end of method
    
    @GetMapping
    @RequestMapping("/emailExists/{email}")
    public boolean emailExists(@PathVariable String email) {//Only one user can be found
        User user = userRepository.emailExists(email);
        if(user == null) {
        	return false;
        }
        return true;
    }//end of method
    
    @GetMapping
    @RequestMapping("/login/{username}/{email}")
    public boolean logIn(@PathVariable String username,@PathVariable String email) {
    	User user = userRepository.validUserCredentials(username, email);
    	if(user == null) {
    		return false;
    	}
    	else {
    		return true;
    	}//end of else
    }//end of method
    
    @GetMapping
    @RequestMapping("/register/{username}/{email}")
    public void registerUser(@PathVariable String username,@PathVariable String email) throws UserAlreadyExistsException {
		User user = this.userRepository.validUserCredentials(username, email);
    	if(user != null) {
    		throw new UserAlreadyExistsException("User already exists!");
    	} 
    	user = new User(username,email);
    	this.userRepository.save(user);    	
	}//end of method
    
    @GetMapping
    @RequestMapping("/lessthan10comments/{username}/{postid}")
    boolean userHasLessThan10CommentOnPost(@PathVariable String username,@PathVariable Long postid) {
    	return this.userRepository.userHasLessThan10CommentOnPost(username, postid);
    }//end of method
    
    
}//end of class
