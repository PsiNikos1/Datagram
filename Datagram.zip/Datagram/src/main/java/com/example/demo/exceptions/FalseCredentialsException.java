package com.example.demo.exceptions;

import javax.security.sasl.AuthenticationException;

public class FalseCredentialsException extends AuthenticationException  {

	public FalseCredentialsException(String message) {
        super(message);
    }
	
	
}//end of class
