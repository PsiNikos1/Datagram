package com.example.demo.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.NoPostsFoundException;
import com.example.demo.exceptions.PostContentTooLong;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.PostRepository;

import org.springframework.web.bind.annotation.PathVariable;


@RestController
@RequestMapping("/posts")
public class PostController {

	@Autowired
	private PostRepository postRepository;
		
	@GetMapping("/findPostByUsername/{username}")
	public List<Post> findPostByUsername(@PathVariable String username) {
		List<Post> desiredUsersPosts = postRepository.findPostFromUser(username);		 
		if (!desiredUsersPosts.isEmpty()) {
			for(Post p : desiredUsersPosts) {
				System.out.println(p);
			}
			return desiredUsersPosts;
	    } 
		else{
	        throw new NoPostsFoundException("No posts found for the user");
	    }		
	}//end of method
	
	
	
	@GetMapping("/findPostsFromUserReverseOrder/{username}")
	List<Post> findPostsFromUserReverseOrder(@PathVariable String username){
		List<Post> desiredUsersPostsReverseOrder = postRepository.findPostsFromUserReverseOrder(username);
		if (!desiredUsersPostsReverseOrder.isEmpty()) {
			for(Post p : desiredUsersPostsReverseOrder) {
				System.out.println(p);
			}
			return desiredUsersPostsReverseOrder;
	    } 
		else{
	        throw new NoPostsFoundException("No posts found for the user");
	    }	

	}//end of method
	
	
	
	
//	private boolean canUserAddComment(User user, Post post) {
//        boolean userCommentCount = postRepository.countCommentsByUserAndPost(user, post);
//        return userCommentCount;
//    }
}//end of class
