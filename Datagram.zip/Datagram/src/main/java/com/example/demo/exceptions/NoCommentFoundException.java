package com.example.demo.exceptions;

public class NoCommentFoundException extends Exception {

	
	public NoCommentFoundException(String message) {
		super(message);
	}//end of constructor
}//end of class
