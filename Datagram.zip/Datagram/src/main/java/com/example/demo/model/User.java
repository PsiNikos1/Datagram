package com.example.demo.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
public class User {

	
	@Id
    @Column(name = "username") 
    private String username;

    @Column(unique = true) 
    private String email;
	
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<Post> posts;
	
    @ManyToMany(mappedBy = "following", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<User> followers;

    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(
        name = "follows",
        joinColumns = @JoinColumn(name = "user1email"),
        inverseJoinColumns = @JoinColumn(name = "user2email")
    )
    private List<User> following;

    
	public User(String username, String email) {
		this.username = username;
		this.email = email;
		this.followers = new ArrayList<User>();
		this.following = new ArrayList<User>();

	}


	public User() {
		this.followers = new ArrayList<User>();
		this.following = new ArrayList<User>();
	}
	
	public void addFollower(User user) {
		this.followers.add(user);
	}//end of method
	
	public void addFollowing(User user) {
		this.following.add(user);
	}//end of method
	
	
	public void removeFollower(User user) {
		this.followers.remove(user);
	}//end of method
	
	public void removeFollowing(User user) {
		this.following.remove(user);
	}//end of method

	@Override
	public String toString() {
		String user = "Username: "+this.username+",email:"+this.email;
		return user;
	}	

	public List<User> getFollowers(){
		return this.followers;
	}
	
	public List<User> getFollowing(){
		return this.following;
	}
	
	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}

}//end of class
