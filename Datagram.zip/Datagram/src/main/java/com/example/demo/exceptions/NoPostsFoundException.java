package com.example.demo.exceptions;

public class NoPostsFoundException extends RuntimeException {
    public NoPostsFoundException(String message) {
        super(message);
    }
}