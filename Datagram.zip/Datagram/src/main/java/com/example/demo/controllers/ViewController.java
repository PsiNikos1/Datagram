package com.example.demo.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.PostContentTooLong;
import com.example.demo.model.Comment;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.CommentRepository;
import com.example.demo.repos.PostRepository;
import com.example.demo.repos.UserRepository;
import com.example.demo.services.PostService;

@RestController
@RequestMapping("/view")
public class ViewController {

	private final int MAX_NUMBER_OF_COMMENTS_PER_POST = 99;
	@Autowired
    private UserRepository userRepository;
	@Autowired
	private PostRepository postRepo;
	@Autowired
	private PostService postService;
	@Autowired
	private CommentRepository commentRepo;
	
	
    public User usernameExists( String username) {//Only one user can be found
        User user = userRepository.usernameExists(username);
    	if(user == null) {
        	return null;
        }
        return user;    
    }//end of method
    
    @GetMapping("/uploadPost/{username}/{content}")
	@ResponseBody
	public String uploadPost(@PathVariable String username, @PathVariable String content) throws PostContentTooLong {
		User author = usernameExists(username);
		if(author == null) {
			return "User not found";
		}
		
		Post newPost = new Post(author, new Date(), content);
		this.postService.savePost(newPost);
		return newPost.toString();
	}//end of method
    
	@GetMapping("/getFollowers/{username}")
	@ResponseBody
    public  String getFollowers(@PathVariable String username){
        String response = "Followers of user "+username+" :<br>";
        User user = usernameExists(username);
        if(user!=null) {
        	for(User follower : user.getFollowers()) {
        		response+= "<br>"+follower.toString()+"<br>";
        	}
        	return response;
        }
        else {
        	return "User not found";
        }
        
    }//end of method
	
	@GetMapping("/getFollowingUsers/{username}")
	@ResponseBody
	public  String getFollowingUsers(@PathVariable String username){
        String response = username+" is following :<br>";
        User user = usernameExists(username);
        if(user!=null) {
        	for(User follower : user.getFollowing()) {
        		response+= "<br>"+follower.toString()+"<br>";
        	}
        	return response;
        }
        else {
        	return "User not found";
        }	
        
    }//end of method
	
	
	
	@GetMapping("/getPostsFromFollowingUsers/{username}")
    @ResponseBody
    public  String getPostsFromFollowingUsers(@PathVariable String username) {
        String response = "Posts of the users "+username+" is following :<br>";
    	User user = usernameExists(username);

        if(user!=null) {
        	for(User follower : user.getFollowing()) {       
        		
            	List<Post> posts =this.postRepo.findPostsFromUserReverseOrder(follower.getUsername());
            	for(Post post : posts) {
            		response += "<br>"+post.toString()+"";
            		List<Comment> comments = this.commentRepo.findCommentsByPostId(post.getId());
            		for(Comment comment : comments) {
                		response += "<br>#####"+comment.toString()+"";

            		}//end of inner for
            		response+="<br>";
            	}//end for
        	}//end of outter for
        	return response;
        }//end if
        else {
        	return "User not found";
        }
    }//end of method
	
	@GetMapping("/getPostsFromUser/{username}")
    @ResponseBody
    public  String getPostsFromUser(@PathVariable String username) {    
    	String response = "Posts of the user: "+username +". Up to 100 comments ordered by reverse chronological order.";
    	User user = usernameExists(username);

        if(user!=null) {
        	List<Post> posts =this.postRepo.findPostsFromUserReverseOrder(user.getUsername());
        	for(Post post : posts) {
        		response += "<br>"+post.toString()+"";
        		List<Comment> comments = this.commentRepo.findCommentsByPostId(post.getId());
        		int counter = 0;
        		outerLoop:
        		for(Comment comment : comments) {
            		response += "<br>#####"+comment.toString()+"";
        			counter ++;
        			if(counter >MAX_NUMBER_OF_COMMENTS_PER_POST) {
        				break outerLoop;
        			}

        		}//end of inner for
        	}
        	return response;
        }
        else {
        	return "user not found";
        }
	}//end of method
	
}//end of class
