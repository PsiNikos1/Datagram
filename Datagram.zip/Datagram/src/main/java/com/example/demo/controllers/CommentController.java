package com.example.demo.controllers;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.MaxNumberOfCommentOnPostException;
import com.example.demo.model.Comment;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.CommentRepository;
import com.example.demo.repos.PostRepository;
import com.example.demo.repos.UserRepository;
import com.example.demo.services.PostService;

@RestController
@RequestMapping("/comments")
public class CommentController {

	@Autowired
	private CommentRepository commentRepository;
	@Autowired
	private PostRepository postRepository;
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/postComment/{username}/{postid}/{content}")
	public void postComment(@PathVariable String username, @PathVariable Long postid, @PathVariable String content) throws MaxNumberOfCommentOnPostException{
		
		if(this.userRepository.userHasLessThan10CommentOnPost(username, postid)) {
			User user = this.userRepository.usernameExists(username);
			Post post = this.postRepository.findPostById(postid);
			Comment newComment = new Comment(user, post, new Date(), content );
			this.commentRepository.save(newComment);

		}
		else {
			throw new MaxNumberOfCommentOnPostException("User has reached 10 comments on this post.");
		}
	}
	
}//end of class
