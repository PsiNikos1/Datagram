package com.example.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.repos.FollowsRepository;

import jakarta.transaction.Transactional;

@RestController
@RequestMapping("/follows")

public class FollowsController {

	@Autowired
	FollowsRepository followsRepository;
	
	@GetMapping("/{username1}/{username2}")
	public boolean userFollowsUser(@PathVariable String username1, @PathVariable String username2) {//user1 follows user2.
		return this.followsRepository.userFollowsUser(username1, username2);
	}

//	@Transactional
//	@GetMapping("/deleteFollower/{username1}/{username2}")
//	public void delFollower(@PathVariable String username1, @PathVariable String username2) {//user1 follows user2.
//		 this.followsRepository.deleteFollowStatus(username1, username2);
//		 }

}//end of class
