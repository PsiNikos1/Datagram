package com.example.demo.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, String>{

	@Query("SELECT u FROM User u WHERE u.email = :email")
	public User emailExists(@Param("email") String email);

	@Query("SELECT u FROM User u WHERE u.username = :username")
	public User usernameExists(@Param("username") String username);
	
    @Query("SELECT u FROM User u WHERE u.username = :username AND u.email= :email")
	public User validUserCredentials(@Param("username") String username, @Param("email") String email);
	
    @Query("SELECT COUNT(c) < 10 FROM Comment c WHERE c.user.username = :username AND c.post.id = :postId")
    boolean userHasLessThan10CommentOnPost(@Param("username") String username, @Param("postId") Long postId);
    
    @Query("SELECT COUNT(c) FROM User c")
    int numberOfRegisteredUsers();
    
    @Query("SELECT u FROM User u")
    List<User> getAllUsers();
}
