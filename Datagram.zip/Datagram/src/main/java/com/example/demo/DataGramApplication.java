package com.example.demo;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.example.demo.model.Comment;
import com.example.demo.model.Follows;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.CommentRepository;
import com.example.demo.repos.FollowsRepository;
import com.example.demo.repos.PostRepository;
import com.example.demo.repos.UserRepository;
import com.example.demo.services.CommentService;
import com.example.demo.services.FollowsService;
import com.example.demo.services.PostService;
import com.example.demo.services.UserService;

import jakarta.transaction.Transactional;

@SpringBootApplication
@ComponentScan(basePackages = "com.example.demo")
public class DataGramApplication implements CommandLineRunner{

	@Autowired
    private PostService postService;
	@Autowired
	private UserService userService;
	@Autowired
	private CommentService commentService;
	@Autowired
	private FollowsService followsService;

	public static void main(String[] args) {
        SpringApplication.run(DataGramApplication.class, args);
        
        
        
    }

    @Override
    @Transactional
    public void run(String... args) throws Exception {
        System.out.print("App started...\n");

        User nikos = this.userService.logIn("nikos", "nikos"); 
        User ilias = this.userService.logIn("ilias", "ilias"); 
        
        //nikos uploads his first post.
        Post post1 = new Post(nikos, new Date(), "This is my first post!");
        this.postService.savePost(post1);
        
        //ilias answers to nikos's post.
        Comment comment1 = new Comment(ilias, post1, new Date(), "Hello Nikos, welcome to Datagram.");
        this.commentService.saveComment(comment1);
        
        //nikos answers back.
        Comment comment2 = new Comment(nikos, post1, new Date(), "Hi!");
        this.commentService.saveComment(comment2);
           
        Follows newFollow = new Follows(nikos,ilias);
        this.followsService.addFollowerStatus(nikos, ilias);
    }
}
