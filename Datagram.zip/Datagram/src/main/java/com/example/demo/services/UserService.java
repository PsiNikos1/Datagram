package com.example.demo.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.exceptions.FalseCredentialsException;
import com.example.demo.exceptions.MaxNumberOfRegisteredUsersException;
import com.example.demo.exceptions.UserAlreadyExistsException;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.PostRepository;
import com.example.demo.repos.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	
	public UserService() {		
	}//end of constructor
	
	@Transactional
	public void saveUser(User user) {  
    	this.userRepository.save(user);    	
    }//end of method
	
	 public User logIn(String username,String email) throws FalseCredentialsException {
		User user = userRepository.validUserCredentials(username, email);
    	if(user == null) {
    		throw new FalseCredentialsException("Failed login. Username or email not correct");
    	}
    	else {
    		return user;
    	}//end of else
    }//end of method
	
	public boolean registerUser(String username, String email) throws UserAlreadyExistsException, MaxNumberOfRegisteredUsersException {
		User user = this.userRepository.validUserCredentials(username, email);
    	if(user != null) {
    		throw new UserAlreadyExistsException("User already exists!");
    	}    
    	if(this.userRepository.numberOfRegisteredUsers() < 500) {
    		User newUser = new User(username, email);
    		saveUser(newUser);
    		return true;
    	}   	
    	else {
    		throw new MaxNumberOfRegisteredUsersException("Reach max registered number of users!");
    	}
	}//end of method
	
	public boolean userHasLessThan10CommentOnPost(User user, Post post) {
		return this.userRepository.userHasLessThan10CommentOnPost(user.getUsername(), post.getId());
	}//end of method
	
	
	
	
}//end of class
