package com.example.demo.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.controllers.PostController;
import com.example.demo.exceptions.PostContentTooLong;
import com.example.demo.model.Comment;
import com.example.demo.model.Post;
import com.example.demo.model.User;
import com.example.demo.repos.PostRepository;

import jakarta.transaction.Transactional;

@Service
public class PostService {

	@Autowired
	private PostRepository postRepository;
	
	
	public PostService() {
		
	}
	
	private boolean hasLessThan1000Characters(String content) {		
        if(content.length()<1001) {
        	return true;
        }
        else {
        	return false;
        }
	}//end of method
	
	@Transactional
	public boolean savePost( Post post) throws PostContentTooLong {
		if(hasLessThan1000Characters(post.getContent())) {
			this.postRepository.save(post);
			return true;
		}//end if
		else {
			throw new PostContentTooLong("Post content is over 1000 characters!");
		}//end else
    }//end of method
	
	public void commentOnPost(Post post, Comment comment) {
		
		
		
	}//end of method
	
}//end of class
