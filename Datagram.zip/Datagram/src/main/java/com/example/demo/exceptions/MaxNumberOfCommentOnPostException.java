package com.example.demo.exceptions;

public class MaxNumberOfCommentOnPostException extends Exception{

	public MaxNumberOfCommentOnPostException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


}
