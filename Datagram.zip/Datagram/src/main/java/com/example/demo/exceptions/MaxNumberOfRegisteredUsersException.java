package com.example.demo.exceptions;

public class MaxNumberOfRegisteredUsersException extends Exception{

	public MaxNumberOfRegisteredUsersException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
