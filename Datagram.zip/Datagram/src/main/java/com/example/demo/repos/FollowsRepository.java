package com.example.demo.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Comment;
import com.example.demo.model.Follows;

import jakarta.transaction.Transactional;

@Repository
public interface FollowsRepository extends JpaRepository<Follows, Long>{

	//@Query("SELECT u FROM Follows u WHERE u.user1email= :username1 AND u.user2email= :username2")
	@Query("SELECT COUNT(u) > 0 FROM Follows u WHERE u.follower.email = :email1 AND u.followed.email = :email2")
	boolean userFollowsUser(@Param("email1") String email1, @Param("email2") String email2);

    @Modifying
    @Transactional
    @Query("DELETE FROM Follows f WHERE f.follower.email = :user1email AND f.followed.email = :user2email")
    void deleteFollowStatus(@Param("user1email") String user1email, @Param("user2email") String user2email);
    

}//end class
