package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "follows")
public class Follows {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

	@ManyToOne
    @JoinColumn(name = "user1email", nullable = false)
    private User follower;

    @ManyToOne	
    @JoinColumn(name = "user2email", nullable = false)
    private User followed;
	
    public Follows(User follower, User followed) {
        this.follower = follower;
        this.followed = followed;
    }

    public Follows() {
    }
    
   
	
}//end of class
